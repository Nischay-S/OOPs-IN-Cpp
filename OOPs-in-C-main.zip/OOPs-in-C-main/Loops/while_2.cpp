#include <iostream>//print series of odd number between 1 to 20
using namespace std;

int main() {
    int i = 1;
    while (i <= 20) {
        cout << i << " ";
        i += 2;
    }
    return 0;
}
