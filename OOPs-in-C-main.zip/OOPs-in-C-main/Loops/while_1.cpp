#include <iostream>//to print 10 to 1
using namespace std;

int main() {
    int i = 10;
    while (i >= 1) {
        cout << i << " ";
        i--;
    }
    return 0;
}
