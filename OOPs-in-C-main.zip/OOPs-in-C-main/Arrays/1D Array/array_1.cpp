#include <iostream>//print array of 5 elements
using namespace std;

int main() {
    int a[5] = {1, 2, 3, 4, 5};
    for (int i = 0; i < 5; i++) {
        cout << a[i] << " ";
    }
    return 0;
}
